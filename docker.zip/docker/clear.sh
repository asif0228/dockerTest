sudo docker-compose down
# sudo docker system prune -af