sudo docker-compose down
sudo docker system prune -af
sudo docker-compose up -d